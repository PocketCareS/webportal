import React, { Component } from 'react';
import '../css/overviewCard.css';

class OverviewCard extends Component {
    state = {}
    render() {
        return (
            <div className="card bg-light mb-3">
                <div className="card-header">Overview</div>
                <div className="card-body">
                    <p className="card-text">Date Updated: <span className="data-value">29th July 2020</span></p>
                    <p className="card-text">Total Confirmed Cases: <span className="data-value">393762</span></p>
                    <p className="card-text">Total Recovered: <span className="data-value">70487</span></p>
                    <p className="card-text">Recent Daily Increase: <span className="data-value">524</span></p>
                </div>
            </div >
        );
    }
}

export default OverviewCard;