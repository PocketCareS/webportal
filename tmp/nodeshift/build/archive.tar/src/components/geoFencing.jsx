import React, { Component } from 'react';
import '../css/geoFencing.css';

class GeoFencing extends Component {
    state = {}
    render() {
        return (
            <p className="geo-fencing-page-title">Geo Fencing</p>
        );
    }
}

export default GeoFencing;